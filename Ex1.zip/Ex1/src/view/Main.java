package view;
import controller.RedesController;

public class Main {
 
	public static void main(String[] args) {
		
		RedesController redcontroller = new RedesController();
		String os = redcontroller.os();
		
		System.out.println(os);
		
		
		
	} 
}
